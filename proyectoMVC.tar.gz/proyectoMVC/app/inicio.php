<?php
//Cargar clases
define("RUTA_APP","/u/proyectoMVC/");
require_once("libs/MySQLdb.php");
require_once("libs/Controlador.php");
require_once("libs/Control.php");
?>